package com.cognizant.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeDemo {
	
public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		GroceriesShop groceriesShop1 = context.getBean("provisionStore", GroceriesShop.class);
		
		GroceriesShop groceriesShop2 = context.getBean("provisionStore", GroceriesShop.class);
		
		boolean isSame = (groceriesShop1 == groceriesShop2);
		
		System.out.println("Both are same instance: "+isSame);
		
		
	}

}
