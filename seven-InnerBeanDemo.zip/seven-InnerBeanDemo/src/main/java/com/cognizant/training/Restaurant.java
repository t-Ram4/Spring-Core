package com.cognizant.training;


public class Restaurant {
	
	GroceriesShop GopalProvisionsStore;
	
	VegetableShop MuruganVegetableMart;
	
	DelivaryBoy delivaryBoy;
	
	public DelivaryBoy getDelivaryBoy() {
		return delivaryBoy;
	}




	public void setDelivaryBoy(DelivaryBoy delivaryBoy) {
		System.out.println("inside setDelivaryBoy method ");
		this.delivaryBoy = delivaryBoy;
	}




	public Restaurant() {
		
		System.out.println("inside default constructor of Restaurant");
	}
	
	
	
	
	public void prepareMeal() {
		
		
		
		GopalProvisionsStore.supplyGroceries();
		
		MuruganVegetableMart.supplyVegetables();
		
		System.out.println("Meals is prepared");
	}
	
	
	public void serveMeal() {
		
		prepareMeal();
		System.out.println("Meal is served");
		
	}




	public GroceriesShop getGopalProvisionsStore() {
		return GopalProvisionsStore;
	}




	public void setGopalProvisionsStore(GroceriesShop gopalProvisionsStore) {
		System.out.println("inside setGopalProvisionsStore method ");
		GopalProvisionsStore = gopalProvisionsStore;
	}




	public VegetableShop getMuruganVegetableMart() {
		return MuruganVegetableMart;
	}




	public void setMuruganVegetableMart(VegetableShop muruganVegetableMart) {
		
		System.out.println("inside setMuruganVegetableMart method ");
		MuruganVegetableMart = muruganVegetableMart;
	}
	
	
	
	
	
}
