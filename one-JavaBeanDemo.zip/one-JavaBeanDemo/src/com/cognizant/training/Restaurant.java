package com.cognizant.training;


public class Restaurant {
	
	
	public void serveMeal() {
		
		System.out.println("Meal is served");
		
	}
	
	
	
	
	
}
