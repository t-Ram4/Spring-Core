package com.cognizant.training;

import java.util.Iterator;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MapDemo {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Restaurant restaurant =  context.getBean("saravanabhavan",Restaurant.class);
		
		
		Map delivaryBoyMap = restaurant.getDelivaryBoysMap();
		
		System.out.println("Delivary boys: "+delivaryBoyMap);
		
		Iterator <Integer> it = delivaryBoyMap.keySet().iterator();       //keyset is a method 
		
		while(it.hasNext())  
		{  
		
		DelivaryBoy delivaryBoy = (DelivaryBoy) delivaryBoyMap.get(it.next());
		
		delivaryBoy.deliverOrder();
		
		}  
		
		
		
	}

}
