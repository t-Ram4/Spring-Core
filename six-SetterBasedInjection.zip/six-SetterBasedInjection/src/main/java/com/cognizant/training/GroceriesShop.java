package com.cognizant.training;
public class GroceriesShop {
	
	
	public GroceriesShop() {
		
		System.out.println("inside default constructor of GroceriesShop");
	}
	
public void supplyGroceries() {
		
		System.out.println("Groceries supplied");
	}

}
