package com.cognizant.training;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class springConfig {
	
	
	@Bean(name = "saravanabhavan")
	public Restaurant getRestaurant() {
		
		Restaurant restaurant = new Restaurant();
		
		
		restaurant.setGopalProvisionsStore(getGroceriesShop());
		
		restaurant.setMuruganVegetableMart(getVegetableShop());
		
		return restaurant;
	}

	@Bean()
	public  VegetableShop getVegetableShop() {
		// TODO Auto-generated method stub
		
		VegetableShop vegetableShop = new VegetableShop();
		return vegetableShop;
	}

	@Bean()
	public  GroceriesShop getGroceriesShop() {
		
		GroceriesShop groceriesShop = new GroceriesShop();
		return groceriesShop;
	}

}
