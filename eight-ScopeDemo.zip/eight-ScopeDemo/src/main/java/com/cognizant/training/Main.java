package com.cognizant.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Restaurant restaurant1 =  context.getBean("saravanabhavan",Restaurant.class);
		
		Restaurant restaurant2 =  context.getBean("saravanabhavan",Restaurant.class);
		
		boolean isSame = (restaurant1 == restaurant2);
		
		System.out.println("Both are same instance: "+isSame);
		
		
	}

}
