package com.cognizant.training;

import org.springframework.stereotype.Component;

@Component
public class GroceriesShop {
	
	
	public GroceriesShop() {
		
		System.out.println("inside default constructor of GroceriesShop");
	}
	
public void supplyGroceries() {
		
		System.out.println("Groceries supplied");
	}

}
