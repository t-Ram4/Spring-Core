package com.cognizant.training;


public class Restaurant {
	
	GroceriesShop GopalProvisionsStore;
	
	VegetableShop MuruganVegetableMart;
	
	
	public void prepareMeal() {
		
		GopalProvisionsStore = new GroceriesShop();
		
		MuruganVegetableMart = new VegetableShop();
		
		GopalProvisionsStore.supplyGroceries();
		
		MuruganVegetableMart.supplyVegetables();
		
		System.out.println("Meals is prepared");
	}
	
	
	public void serveMeal() {
		
		prepareMeal();
		System.out.println("Meal is served");
		
	}
	
	
	
	
	
}
