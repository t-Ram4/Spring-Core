package com.cognizant.training;

public class Main {
	
	public static void main(String arg[]) {
		
		GroceriesShop GopalProvisionsStore = new GroceriesShop();
		
		VegetableShop MuruganVegetableMart = new VegetableShop();
		
		Restaurant saravanabhavan = new Restaurant(GopalProvisionsStore,MuruganVegetableMart);
		
		saravanabhavan.serveMeal();
		
		
	}

}
