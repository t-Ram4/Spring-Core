package com.cognizant.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Restaurant restaurant =  context.getBean("saravanabhavan",Restaurant.class);
		
		restaurant.getDelivaryBoy().deliverOrder();
		
		
	}

}
