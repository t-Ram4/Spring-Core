package com.cognizant.training;

public class DelivaryBoy {
	
	public DelivaryBoy() {
		
		System.out.println("inside default constructor of DelivaryBoy");
	}
	
	public void deliverOrder() {
		
		System.out.println("Order is delivered at customer doorsteps");
	}

}
